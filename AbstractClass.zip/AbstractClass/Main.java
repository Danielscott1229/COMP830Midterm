package com.AbstractClass;

import java.util.ArrayList;
import java.util.Iterator;

public class Main {

    public static void main(String[] args) {
        ArrayList shipList = new ArrayList<SpaceShip>();

        StarWarsShip MilleniumFalcon = new StarWarsShip("Millenium Falcon", 20);
        StarWarsShip StarDestroyer = new StarWarsShip("Star Destroyer", 100);
        StarWarsShip X_Wing = new StarWarsShip("X Wing", 5);
        StarTrekShip USS_Enterprise = new StarTrekShip("USS Enterprise", 40);
        StarTrekShip USS_Enterprise_B = new StarTrekShip("USS Enterprise B", 40);
        StarTrekShip Borg_Cube = new StarTrekShip("Borg Cube", 80);
        OtherSciFiShip Serenity = new OtherSciFiShip("Serenity", 40, "Firefly");
        OtherSciFiShip Battlestar_Galactica = new OtherSciFiShip("Battlestar Galactica", 60, "Battlestar Galactica");
        OtherSciFiShip Discovery_One = new OtherSciFiShip("Discovery One", 15, "2001: A Space Odyssey");

        shipList.add(MilleniumFalcon);
        shipList.add(StarDestroyer);
        shipList.add(X_Wing);
        shipList.add(USS_Enterprise);
        shipList.add(USS_Enterprise_B);
        shipList.add(Borg_Cube);
        shipList.add(Serenity);
        shipList.add(Battlestar_Galactica);
        shipList.add(Discovery_One);

        System.out.println("Science Fiction Ship Inventory:");

        for (int i = 1; i < shipList.size() + 1; i++) {
            SpaceShip currentShip = (SpaceShip) shipList.get(i-1);

            System.out.println(i + ". Name: " + currentShip.getName()  + "    Tonnage: " +
            currentShip.getTonnage() + "    Franchise: " + currentShip.getFranchise());
        }
    }
}
