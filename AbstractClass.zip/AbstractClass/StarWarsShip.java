package com.AbstractClass;

public class StarWarsShip extends SpaceShip {

    StarWarsShip(String n, int t) {
        name = n;
        tonnage = t;
    }

    public String getFranchise() {
        return "Star Wars";
    }
}
