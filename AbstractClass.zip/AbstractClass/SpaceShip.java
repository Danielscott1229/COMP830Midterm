package com.AbstractClass;

public abstract class SpaceShip {

    int tonnage;

    String name;

    public int getTonnage() {return tonnage; }

    public String getName() {return name;}

    abstract public String getFranchise(); // Star Wars, Star Trek, or some other Sci-fi universe

}
