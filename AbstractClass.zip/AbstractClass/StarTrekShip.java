package com.AbstractClass;

public class StarTrekShip extends SpaceShip {

    StarTrekShip(String n, int t) {
        name = n;
        tonnage = t;
    }

    public String getFranchise() {
        return "Star Trek";
    }
}
