package com.AbstractClass;

public class OtherSciFiShip extends SpaceShip {

    String franchise;

    OtherSciFiShip(String n, int t, String f) {
        name = n;
        tonnage = t;
        franchise = f;
    }

    public String getFranchise() {
        return franchise;
    }
}