package com.State;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    PoolMember pm = new PoolMember();
	    String input = "";
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to the Pool Member State Machine!");
        pm.printState();

        while (true) {
            System.out.println("    Please type one of the following commands to make a selection:");
            System.out.println("    unknown: Switch the Pool Member to the unknown state");
            System.out.println("    available: Switch the Pool Member to the available state");
            System.out.println("    unavailable: Switch the Pool Member to the unavailable state");
            System.out.println("    quit: Exit out of the program");
            input = scan.nextLine();
            switch (input) {
                case "unknown":
                    pm.switchUnknown();
                    break;
                case "available":
                    pm.switchAvailable();
                    break;
                case "unavailable":
                    pm.switchUnavailable();
                    break;
                case "quit":
                    System.exit(-1);
                default:
                    System.out.println("Error: Invalid command");
                    break;
            }
            pm.printState();
        }
    }
}
