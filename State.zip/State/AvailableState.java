package com.State;

public class AvailableState implements MemberState {
    @Override
    public void switchAvailable(PoolMember pm) {
        pm.setState(new AvailableState());
    }
    @Override
    public void switchUnavailable(PoolMember pm) {
        pm.setState(new UnavailableState());
    }
    @Override
    public void switchUnknown(PoolMember pm) {
        pm.setState(new UnknownState());
    }
    public String getState() {
        return "Available";
    }
}