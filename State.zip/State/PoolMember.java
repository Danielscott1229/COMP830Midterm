package com.State;

public class PoolMember {
    private MemberState state = new UnknownState();

    public void setState (MemberState ms) {
        state = ms;
    }

    public void printState () {
        System.out.println("The current state is: " + state.getState());
    }

    public void switchAvailable() {
        state.switchAvailable(this);
    }
    public void switchUnavailable() {
        state.switchUnavailable(this);
    }
    public void switchUnknown() {
        state.switchUnknown(this);
    }
}