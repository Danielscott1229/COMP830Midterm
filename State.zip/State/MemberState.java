package com.State;

public interface MemberState {
    void switchAvailable(PoolMember pm);
    void switchUnavailable(PoolMember pm);
    void switchUnknown(PoolMember pm);
    public String getState();
}