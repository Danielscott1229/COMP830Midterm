package com.Strategy;

public class Main {

    public static void main(String[] args) {
	BookLibrarian librarian = new BookLibrarian();
	BookInformation frankenstein  = new BookInformation("Mary Shelley", "Frankenstein", 1840, "A scientist creates life");
	BookInformation moby_dick = new BookInformation("Herman Melville", "Moby Dick", 1851, "A man chases a white whale");
    BookInformation lord_of_the_rings  = new BookInformation("JRR Tolkien", "Lord of the Rings", 1940, "hobbits must destroy a ring");
    BookInformation the_leader = new BookInformation("James H Smith", "The Leader", 2000, "A biography about president Bill Clinton");
    BookInformation pilgrims_progress = new BookInformation("John Bunyan", "Pilgrim's Progress", 1800, "a man must avoid temptation");
    BookInformation gullivers_travels = new BookInformation("Jonathan Swift", "Gulliver's Travels", 1750, "a man becomes shipwrecked on a strange island");
    BookInformation emma = new BookInformation("Jane Austen", "Emma", 1780, "A story about a girl in the 1800s");
    BookInformation wuthering_heights = new BookInformation("Emily Bronte", "Wuthering Heights", 1890, "A story of loss");
    BookInformation huckleberry_finn = new BookInformation("Mark Twain", "The Adventures of Huckleberry Finn", 1900, "A young boy must learn to do the right thing");
    BookInformation dorian_grey = new BookInformation("Oscar Wilde", "A picture of Dorian Grey", 1780, "A man is cursed to never age");
    BookInformation dracula = new BookInformation("Bram Stoker", "Dracula", 1700, "An ancient monster terrorizes a city");
    BookInformation heart_of_darkness = new BookInformation("Joseph Conrad", "Heart of Darkness", 1920, "A man learns the horrors of war");
    BookInformation ulysses = new BookInformation("James Joyce", "Ulysses", 1600, "The story of three men from dublin");
    BookInformation brave_new_world = new BookInformation("Aldous Huxley", "Brave New World", 1870, "A grim imagining of the future");
    BookInformation book1984 = new BookInformation("George Orwell", "1984", 1948, "The world is watched over by Big Brother");
    BookInformation grapes_of_wrath = new BookInformation("John Steinbeck", "The Grapes of Wrath", 1898, "A classic american novel");
    BookInformation catcher_in_the_rye = new BookInformation("JD Salinger", "The Catcher in the Rye", 1982, "A study of teenage rebellion");
    BookInformation lord_of_the_flies = new BookInformation("William Golding", "The Lord of the Flies", 1743, "A group of young men must survive on an island");
    BookInformation tkam = new BookInformation("Harper Lee", "To Kill a Mockingbird", 1822, "A lawyer tries to bring justice for a falsely accused man");
    BookInformation robinson_crusoe = new BookInformation("Daniel Dafoe", "Robinson Crusoe", 1700, "A man sails to a strange place");

    librarian.addBook(frankenstein);
    librarian.addBook(moby_dick);
    librarian.addBook(lord_of_the_rings);
    librarian.addBook(the_leader);
    librarian.addBook(pilgrims_progress);
    librarian.addBook(gullivers_travels);
    librarian.addBook(emma);
    librarian.addBook(wuthering_heights);
    librarian.addBook(huckleberry_finn);
    librarian.addBook(dorian_grey);
    librarian.addBook(dracula);
    librarian.addBook(heart_of_darkness);
    librarian.addBook(ulysses);
    librarian.addBook(brave_new_world);
    librarian.addBook(book1984);
    librarian.addBook(grapes_of_wrath);
    librarian.addBook(catcher_in_the_rye);
    librarian.addBook(lord_of_the_flies);
    librarian.addBook(tkam);
    librarian.addBook(robinson_crusoe);

    BookSort author = new BookSort("author");
    librarian.setSortMethod(author);
    librarian.sort();
    librarian.printlist();

    BookSort title = new BookSort("title");
    librarian.setSortMethod(title);
    librarian.sort();
    librarian.printlist();

    BookSort year = new BookSort("year");
    librarian.setSortMethod(year);
    librarian.sort();
    librarian.printlist();
    }
}
