package com.Strategy;

public class BookSort {
    String method;
    public BookSort(String m) {
        method = m;
    }
    public String getMethod() {
        return method;
    }
}
