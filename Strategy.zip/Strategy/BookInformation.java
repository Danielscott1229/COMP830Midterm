package com.Strategy;

public class BookInformation {
    String author;
    String title;
    int yearpublished;
    String summary;

    public BookInformation(String a, String t, int y, String s) {
        author = a;
        title = t;
        yearpublished = y;
        summary = s;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return yearpublished;
    }

    public String getSummary() {
        return summary;
    }
}
