package com.Strategy;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Collections;

public class BookLibrarian {
    ArrayList books = new ArrayList<BookInformation>();
    BookSort sortMethod;

    public void addBook(BookInformation b) {
        books.add(b);
    }

    public void setSortMethod(BookSort bs) {
        sortMethod = bs;
    }

    public void sort() {
        String method = sortMethod.getMethod();
        switch (method) {
            case "author":
                for (int t = 0; t < books.size() - 1; t++) {
                    for (int i = 0; i < books.size() - t - 1; i++) {
                        BookInformation currentBook = (BookInformation) books.get(i);
                        BookInformation nextBook = (BookInformation) books.get(i + 1);
                        String currentAuthor = currentBook.getAuthor();
                        String nextAuthor = nextBook.getAuthor();
                        if (currentAuthor.compareTo(nextAuthor) > 0) {
                            Collections.swap(books, i, i + 1);
                        }
                    }
                }
                break;
            case "title":
                for (int t = 0; t < books.size() - 1; t++) {
                    for (int i = 0; i < books.size() - t - 1; i++) {
                        BookInformation currentBook = (BookInformation) books.get(i);
                        BookInformation nextBook = (BookInformation) books.get(i + 1);
                        String currentTitle = currentBook.getTitle();
                        String nextTitle = nextBook.getTitle();
                        if (currentTitle.compareTo(nextTitle) > 0) {
                            Collections.swap(books, i, i + 1);
                        }
                    }
                }
                break;
            case "year":
                for (int t = 0; t < books.size() - 1; t++) {
                    for (int i = 0; i < books.size() - t - 1; i++) {
                        BookInformation currentBook = (BookInformation) books.get(i);
                        BookInformation nextBook = (BookInformation) books.get(i + 1);
                        int currentYear = currentBook.getYear();
                        int nextYear = nextBook.getYear();
                        if (currentYear > nextYear) {
                            Collections.swap(books, i, i + 1);
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    public void printlist(){
        String method = sortMethod.getMethod();
        switch(method) {
            case "author":
                System.out.println("Books sorted by author:");
                break;
            case "title":
                System.out.println("Books sorted by title:");
                break;
            case "year":
                System.out.println("Books sorted by year published:");
                break;
        }
        for (int i = 1; i < books.size() + 1; i++) {
            BookInformation currentBook = (BookInformation) books.get(i-1);

            System.out.println(i + ". Title: " + currentBook.getTitle()  + "    Author: " +
                    currentBook.getAuthor() + "    Year Published: " + currentBook.getYear() +
                    "    Summary: " + currentBook.getSummary());
        }
        System.out.println("");
    }
}
